Please note that csv6a and csv6b contain the field score_mean that should not be used in this task. 
Due to technical issues it was not possible to recalculate the two csv files without it in time.
Thanks.